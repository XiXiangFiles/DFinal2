package com.example.user.dfinal2;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class mainpage extends Activity {

    String U_Num="";
    String U_Name="";
    String keep="";
    String Email="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainpage);
        Intent intent = this.getIntent();
        ArrayList<String> a=intent.getStringArrayListExtra("User");
        Map<String,String> map=new HashMap<>();

        for (String str: a) {
            System.out.println("DATA=\t"+str);
            String []items=str.split(":");
            map.put(items[0],items[1]);
        }
        for(Map.Entry<String,String> user:map.entrySet()){
            if(user.getKey().equals("U_Num")){
                this.U_Num=user.getValue();
            }
            if(user.getKey().equals("U_Name")){
                this.U_Name=user.getValue();
            }
            if(user.getKey().equals("Email")){
                this.Email=user.getValue();
            }
            if(user.getKey().equals("Keep")){
                this.keep=user.getValue();
            }
        }
        System.out.println("U_Num=\t"+this.U_Num);
        System.out.println("U_Name\t"+this.U_Name);

        ArrayList<String>data=new ArrayList<>();
        data.add("U_Name:"+this.U_Name);
        data.add("U_Num:"+this.U_Num);
        data.add("Email:"+Email);
        Bundle bundle = new Bundle();
        bundle.putStringArrayList("User",data);

        DBsqlite db=new DBsqlite(this);

        DBsqlite dBsqlite= new DBsqlite(this);
        ArrayList a1=dBsqlite.getAll(dBsqlite,map);
        if(a1.size()==0){
            db.insert(db,map);
        }else{
            if (keep.equals("no")){
                System.out.println("Keep=\t"+keep);
                System.out.println("Email=\t"+Email);
                db.delete(db,Email);
            }
        }
        FragmentManager FM=getFragmentManager();
        FragmentTransaction FMT=FM.beginTransaction();
        Account account=new Account();
        FMT.replace(R.id.f_container,account);
        account.setArguments(bundle);
        FMT.commit();



        ImageButton mainpage_bt=(ImageButton)findViewById(R.id.mainpage_bt);
        mainpage_bt.setOnClickListener((View v)->{
            FragmentManager FMfirst=getFragmentManager();
            FragmentTransaction FMfistFT=FMfirst.beginTransaction();
            Account account1=new Account();
            account1.setArguments(bundle);
            FMfistFT.replace(R.id.f_container,account1);
            FMfistFT.commit();

        });

        ImageButton setting=(ImageButton)findViewById(R.id.Setting);
        setting.setOnClickListener((View v)->{
            FragmentManager FMSec=getFragmentManager();
            FragmentTransaction FMSecFT=FMSec.beginTransaction();
            System.out.println("Click!!");
            Setting set=new Setting();
            FMSecFT.replace(R.id.f_container,set);
            set.setArguments(bundle);
            FMSecFT.commit();
        });

    }


}
