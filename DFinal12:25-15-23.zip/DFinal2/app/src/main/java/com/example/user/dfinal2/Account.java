package com.example.user.dfinal2;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class Account extends Fragment {


    String U_Name="";
    String U_Num="";
    public Account() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        Bundle bundle = getArguments();
        ArrayList<String> a=bundle.getStringArrayList("User");
        Map<String,String> map=new HashMap<>();

        for (String str: a) {
            System.out.println("DATA=\t"+str);
            String []items=str.split(":");
            if (str.contains("U_Name")){
                this.U_Name=items[1];
            }
            if (str.contains("U_Num")){
                this.U_Num=items[1];
            }
            map.put(items[0],items[1]);
        }

        return inflater.inflate(R.layout.fragment_account, container, false);
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);

        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String date = sDateFormat.format(new java.util.Date());
        TextView t = (TextView) getView().findViewById(R.id.Today);
        t.setText(date);

        t = (TextView) getView().findViewById(R.id.Today);
        t.setText(date);

        TextView t1 = (TextView) getView().findViewById(R.id.Hello);
        t1.setText(this.U_Name+" 你好！");

        Button Manual=(Button) getView().findViewById(R.id.Manual);
        Manual.setOnClickListener((View v)->{
            Toast toast = Toast.makeText(getActivity(), "TEST！！\t"+ U_Name, Toast.LENGTH_LONG);
            toast.show();
            FragmentManager FMSec=getFragmentManager();
            FragmentTransaction FMSecFT=FMSec.beginTransaction();
            System.out.println("Click!!");
            manualbill mau=new manualbill();
            FMSecFT.replace(R.id.f_container,mau);
            FMSecFT.commit();

        });

    }

}
